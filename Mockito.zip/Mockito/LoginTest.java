package mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.only;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class LoginTest {
	
		@Mock
	  UserDAO userDao;
		@Mock
		 private List<String> list;
	 LoginService loginService;
	 
	   @BeforeEach
	   public void setup() {
	       MockitoAnnotations.initMocks(this);
	   }
	   
	   @Test
	   public void testLogin1(){
		   User user = new User();
		   user.setCity("chennai");
		   user.setUserName("Jack");
		   user.setPassword("jack123");
	       when(userDao.loadByUserNameAndPassword("Jack", "jack123")).thenReturn(user);
	       loginService = new LoginService();
	       loginService.setUserDao(userDao);
	       Boolean actual = loginService.login("Jack", "jack123");
	      Boolean expected = true;
	       assertEquals(expected, actual);
	   }
	   @Test
	   public void testLogin2(){
		   
	      when(userDao.loadByUserNameAndPassword("Jack", "jack123")).thenReturn(null);
	       loginService = new LoginService();
	       loginService.setUserDao(userDao);
	       Boolean actual = loginService.login("Jack", "jack123");
	      Boolean expected = false;
	       assertEquals(expected, actual);
	   }
	   @Test
	   public void testLogin3() {
		   
	       when(userDao.getUserByUserName("Jack")).thenAnswer(invocation -> {
	    	   throw new UserNotFoundException();
	       });
	       loginService = new LoginService();
	       loginService.setUserDao(userDao);

	       assertThrows(UserNotFoundException.class, ()->loginService.getUserByUserName("Jack"));
	   }
	   @Test
	   public void testLogin4() {
		   
	       when(userDao.getUsersByCity("Chennai")).thenThrow(NoUsersInThisCityException.class);
		  
	       loginService = new LoginService();
	       loginService.setUserDao(userDao);

	       assertThrows(NoUsersInThisCityException.class, ()->loginService.getUsersByCity("Chennai"));
	   }
	   @Test
	   public void testLogin5() {
		  User user = new User(); 
	      
		  doThrow(new InvalidUserDetailsException()).when(userDao).addUser(user);
	       loginService = new LoginService();
	       loginService.setUserDao(userDao);
	       assertThrows(InvalidUserDetailsException.class, ()->loginService.addUser(user));
	       //verify(userDao).addUser(any(User.class));
	       //verify(userDao).addUser(any(User.class));
	       verify(userDao,times(2)).addUser(any(User.class));
	       /*verify(userDao,atLeastOnce()).addUser(any(User.class));
	       verify(userDao, never()).getUserByUserName(anyString());
	       verify(userDao,only()).addUser(any(User.class));*/
	      
	      
	   }
	 

}
