package mockito;

import java.util.List;

public interface UserDAO {
	User loadByUserNameAndPassword(String username, String password);
	User getUserByUserName(String userName);
	List<User> getUsersByCity(String city);
	void addUser(User user);
}
