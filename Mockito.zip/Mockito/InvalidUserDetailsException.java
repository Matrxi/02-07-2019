package mockito;

public class InvalidUserDetailsException extends RuntimeException{
	public InvalidUserDetailsException(){
		super("User details invalid");
	}

}
