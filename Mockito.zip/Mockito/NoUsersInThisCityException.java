package mockito;

public class NoUsersInThisCityException extends RuntimeException {
	public NoUsersInThisCityException() {
		super(" No users found in this city");
	}
	
}
